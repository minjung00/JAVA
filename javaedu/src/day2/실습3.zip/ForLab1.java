package day2;

public class ForLab1 {

	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {
			// 공백을 추가하여 결과 출력
            System.out.print(i + " ");
        }
	}

}
